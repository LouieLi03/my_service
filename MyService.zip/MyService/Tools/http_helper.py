# -*- coding:utf-8 -*-

# 业务请求失败failure
REQUEST_FAILURE = 0

# 业务请求成功
REQUEST_SUCCESS = 1
